# DroxAI v1.0.0 - Consumer Edition

## Quick Start

1. **Prerequisites**
   - Windows 10/11
   - Python 3.8 or later (download from python.org)

2. **Installation**
   - No installation required - this is a portable application
   - Extract to any folder on your computer

3. **Running DroxAI**
   - Double-click DroxAI.bat to start
   - Or run: python DroxAI_Launcher.py

4. **Accessing the Interface**
   - Web Dashboard: http://localhost:8000
   - WebSocket API: ws://localhost:8765

## Features

- **Advanced AI Orchestration**: Self-evolving AI system with metacognitive capabilities
- **Web Dashboard**: Real-time monitoring and control interface
- **WebSocket API**: Programmatic access for developers
- **Plugin System**: Extensible architecture for custom functionality
- **Federated Learning**: Distributed AI training capabilities

## Configuration

- Main configuration: config\appsettings.json
- Logs: logs\droxai.log
- Data: data\droxai_memory.db
- Plugins: plugins\ directory

## Troubleshooting

### Port Already in Use
- Edit config\appsettings.json to change ports
- Default HTTP port: 8000
- Default WebSocket port: 8765

### Python Not Found
- Install Python 3.8+ from python.org
- Ensure "Add Python to PATH" is checked during installation

### Permission Errors
- Run as Administrator if needed
- Check antivirus software isn't blocking the application

## System Requirements

- Windows 10/11
- 4GB RAM minimum (8GB recommended)
- 1GB disk space
- Internet connection (for initial setup)

## Support

For issues and support, check the logs directory for error details.

---
© 2025 DroxAI - Advanced AI Orchestration System
Built with consumer-friendly packaging
